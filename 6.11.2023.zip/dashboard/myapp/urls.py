from django.urls import path
from myapp import views
app_name="myapp"
from django.conf.urls.static import static
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [

    path('index/',views.index),
    path('headfoot/',views.headfoot),
    path('profile/',views.profile),
    path('adduser/',views.adduser),
    path('tables/',views.table1),
    path('logtab/',views.logtab),
    path('dashboard/',views.dashboard),
    path('icons/',views.icons1),
    path('forms/',views.forms1),
    path('register2/',views.register),
    path('',views.login1),
    path('calender/',views.calender1),
    path('logout/',views.logoutdata),
    path('edit/<int:pk>/',views.editprofile),
    path('delete/<int:pk>/',views.deleteprofile),
    path('reset_password/',views.reset_password),
    path('forget_password/',views.forget_password),
    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

 
