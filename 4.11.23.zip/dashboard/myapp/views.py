from django.contrib.auth.models import User
from .forms import Formdetails
from .models import Register,loginhistory
from django.contrib.auth import login, authenticate,update_session_auth_hash
from django.contrib.auth import logout
from django.contrib.messages import constants as messages
from django.shortcuts import render,redirect
from django.contrib.auth.forms import PasswordResetForm,PasswordChangeForm
from datetime import timedelta, datetime
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect,HttpResponse
from django.template import loader


def user_access(view_fun):
    def _wrapper_view(request,*args,**kwargs):
        if request.user.is_active:
            return view_fun(request,*args,**kwargs)
        else:
            return redirect('/')
    return  _wrapper_view

def admin_access(view_fun):
    def _wrapper_view(request,*args,**kwargs):
        if request.user.is_superuser:
            return view_fun(request,*args,**kwargs)
        else:
            return redirect('/')
    return  _wrapper_view
@user_access
def index(request):
    if request.user.is_authenticated:

        user9=Register.objects.get(user_id=request.user.id)

        return render(request,"index.html",{'tower':user9})

    return render(request,"index.html")

def register(request):
    if request.method =='POST':
        data=request.POST
        userform=Formdetails(request.POST)
        if userform.is_valid():
            userform.save()
            messages.success(request, "Registration Successfull :)")
            print(userform.instance.id)
            email=data['email']
            Register.objects.create(user_id=userform.instance.id,email=email)
            print(data)
            return redirect("/")
        else:                
                                          
            print(userform.errors)
    return render(request,"register.html")


import datetime
def login1(request):
        print(request.user)
        print(request.POST)
        if request.method == 'POST':
            username = request.POST['username']
            password1 = request.POST['password']
            user = authenticate(request, username=username, password=password1)
            print(user)
            if user is not None:
                     login(request,user)
                     logintableddd=loginhistory.objects.create(username_id=request.user.id)
                     logintableddd.login_status = "Logged In :)"
                     logintableddd.login_time = datetime.datetime.now()
                     logintableddd.save()
                     messages.success(request,"Login Successfull")
                     return redirect('/index')
            else:
                messages.error(request,"Invalid Username/Password")
                return render(request, 'login.html')
        return render(request,"login.html")
@user_access
def profile(request):
    user=Register.objects.get(user_id=request.user.id)
    user1=User.objects.get(id=request.user.id)
    print(user)
    if request.method =='POST':
        data=request.POST
        email=data["email"]
        username=data["username"]
        user.email=email
        user1.username=username
        user.save()
        user1.save()
        messages.success(request,"Profile Edited Successfully")
        return redirect("/profile")
    return render(request,"profile.html",{'user':user})
@user_access
def icons1(request):
    user1=Register.objects.get(user_id=request.user.id)
    return render(request,"icons.html",{'user':user1})
@user_access
def forms1(request):
    user2=Register.objects.get(user_id=request.user.id)
    return render(request,"forms.html",{'user':user2})
@user_access
def calender1(request):
    user3=Register.objects.get(user_id=request.user.id)
    return render(request,"calendar.html",{'user':user3})
@user_access
def table1(request):
    user22=Register.objects.all()
    user23=loginhistory.objects.all()
    user4=Register.objects.get(user_id=request.user.id)
    return render(request,"tables.html",{'user':user22,'user2':user23})
@user_access
def dashboard(request):
    user5=Register.objects.get(user_id=request.user.id)
    return render(request,"index.html",{'user':user5})


def editprofile(request,pk):
        editdata=Register.objects.get(id=pk)
        if request.method == 'POST':
                data=request.POST
                Phone=data['phone']
                city=data['city']
                email=data['email']
                editdata.phone=Phone
                editdata.email=email
                editdata.city=city
                editdata.save()
                return redirect("/tables")
        return render(request,"editprofile.html",{'editdata':editdata})

def adduser(request):
     if request.method =='POST':
        data=request.POST
        userform=Formdetails(request.POST)
        if userform.is_valid():
            userform.save()
            messages.success(request, "USER Added Successfully :)")
            print(userform.instance.id)
            email=data['email']
            phone=data['phone']
            city=data['city']
            Register.objects.create(user_id=userform.instance.id,email=email,phone=phone,city=city)
            print(data)
            return redirect("/tables")
        else:                
                                          
            print(userform.errors)
     return render(request,"add user.html")

def deleteprofile(request,pk):
    editdata=Register.objects.get(id=pk)
    editdata.delete()
    return redirect("/tables")


def reset_password(request):
        userd=User.objects.get(username=request.user)
        if request.method == 'POST': 
                    password=request.POST['password1']
                    userd.set_password(password)
                    userd.save()
                    messages.success(request,"Password Changed Successfully")
                    return redirect('/')
        return render(request,"resetpsswd.html")


def forget_password(request):

        if request.method == 'POST': 
                    email=request.POST["email"]
                    password=request.POST['password']
                    user2=Register.objects.get(email=email)
                    user1=User.objects.get(id=user2.user_id)
                    user1.set_password(password)
                    user1.save()
                    messages.success(request,"Password Changed Successfully")
                    return redirect('/')
        return render(request,"forgotpsswd.html")
    #  if request.method=="POST":
    #     email_id=request.POST.get("email")
    #     password=request.POST.get("password")

    #     password.set_password(password)
    #     password.set_password(password)
    # #  if user.is_valid() and user1.is_valid():
    #  try:
    #     user = Register.objects.get(user_id=request.user.id,email = email_id)
    #     user1=User.objects.get(password=password)
    #     user1.save()
    #     user.save()  
    #     return redirect('/forget_password')
    #  except Register.DoesNotExist:
         
    #   return render(request,"forgotpsswd.html")
     
def headfoot(request):
    return render(request,"headfoot.html")             
     


def logoutdata(request):
     logout(request)
     variable="Logged Out :("
     loginhistory.objects.filter(logout_time__isnull=True).update(logout_time=datetime.datetime.now(),logout_status=variable)
     messages.error(request,"You Are Logged Out :(")
     return redirect('/')

 