from django.db import models
from django.contrib.auth.models import User

class Register(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    email=models.CharField(max_length=50,default=None)
    city=models.CharField(max_length=50,default=None)
    phone=models.CharField(max_length=50,default=None)

class loginhistory(models.Model):
    username=models.ForeignKey(User,on_delete=models.CASCADE)
    login_status=models.CharField(max_length=50,default="Logged In")
    logout_status=models.CharField(max_length=50)
    login_time=models.DateTimeField(auto_now_add=True)
    logout_time=models.DateTimeField(null=True)