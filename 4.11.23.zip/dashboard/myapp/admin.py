from django.contrib import admin
from .models import Register,loginhistory
admin.site.register(loginhistory)
admin.site.register(Register)
# admin.site.register(cart)
# admin.site.register(deposits)
# admin.site.register(myorders)
